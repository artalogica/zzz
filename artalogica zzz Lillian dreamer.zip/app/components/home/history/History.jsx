import React from 'react'
import { View, Text, SafeAreaView} from 'react-native'

import styles from './history.style'

const History = () => {
  return (
    <SafeAreaView>
      {/* <Image 
        source = {{uri}}
        style = {[
          styles.image,
          aviOnly && {height: 35, width:35,
          borderWidth: 0},
          imgStyle,
        ]}
      /> */}
    </SafeAreaView>
  )
}

export default History