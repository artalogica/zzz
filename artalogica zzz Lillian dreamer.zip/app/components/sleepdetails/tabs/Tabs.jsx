import React from 'react'
import { View, Text } from 'react-native'

import styles from './tabs.style'

const Tabs = () => {
  return (
    <View>
      <Text>Tabs</Text>
    </View>
  )
}

export default Tabs