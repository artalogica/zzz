import React from 'react'
import { View, Text } from 'react-native'

import styles from './profile.style'

const Profile = () => {
  return (
    <View>
      <Text>Profile</Text>
    </View>
  )
}

export default Profile