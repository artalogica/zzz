import React from 'react'
import { View, Text } from 'react-native'

import styles from './specifics.style'

const Specifics = () => {
  return (
    <View>
      <Text>Specifics</Text>
    </View>
  )
}

export default Specifics