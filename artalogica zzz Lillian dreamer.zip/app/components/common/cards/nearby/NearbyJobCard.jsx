import React from 'react'
import { View, Text } from 'react-native'

import styles from './nearbyjobcard.style'

const NearbyJobCard = () => {
  return (
    <View>
      <Text>NearbyJobCard</Text>
    </View>
  )
}

export default NearbyJobCard