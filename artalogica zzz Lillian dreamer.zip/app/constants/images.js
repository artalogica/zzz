import profile from "../assets/images/IMG_9926.png";

export default {
  profile,
};
